$(document).ready(function() {
    // Our products will go inside the productContainer
    // var $productContainer = $(".product-container");
    // // Adding event listeners for deleting, editing, and adding todos
    // $(document).on("click", "button.delete", deleteTodo);
    // $(document).on("click", "button.complete", toggleComplete);
    // $(document).on("click", ".todo-item", editTodo);
    // $(document).on("keyup", ".todo-item", finishEdit);
    // $(document).on("blur", ".todo-item", cancelEdit);
    // $(document).on("submit", "#todo-form", insertTodo);
  
    // Our initial products array
    var products = [];
  
    // Getting products from database when page loads
    getProduct();
    // This function grabs product from the database and updates the view
    function getProduct() {
      $.get("/api/product", function(data) {
        // product = data;
        // initializeRows();
        console.log(data);
      });
    }
   })
  