
// *********************************************************************************
// api-routes.js - this file offers a set of routes for displaying data from the db
//new from natasha 
// *********************************************************************************

// Dependencies
// =============================================================

// Requiring our Product model
var db = require("../models");

// Routes
// =============================================================
module.exports = function(app) {

  // GET route for getting all of the todos
  app.get("/api/product", function(req, res) {
    // Write code here to retrieve all of the products from the database and res.json them
    // back to the user
    db.product.findAll({}).then(function(dbProduct){
      res.json(dbProduct);
    });
   });

  // POST route for saving a new todo. We can create todo with the data in req.body
// // //   app.post("/api/todos", function(req, res) {
// //     // Write code here to create a new todo and save it to the database
// //     // and then res.json back the new todo to the user

// //     console.log(req.body);
// //     db.Todo.create({
// //       text: req.body.text,
// //       complete: req.body.complete 
// //     }).then(function(dbTodo){

// //     });
//   });


//   // DELETE route for deleting todos. We can get the id of the todo to be deleted from
//   // req.params.id
//   app.delete("/api/todos/:id", function(req, res) {

//   });

//   // PUT route for updating todos. We can get the updated todo data from req.body
//   app.put("/api/todos", function(req, res) {

//   });
};
